<footer class="main-footer">
    <div class="pull-right hidden-xs">
      Web Design and Development by <a target="_blank" href="http://www.dotcomweavers.com/">DotcomWeavers</a>
    </div>
    <strong>Copyright &copy;  <a href="/" target="_blank">Chrysalis</a></strong> &copy; <?php echo date("Y"); ?> 
  </footer>